package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Brandon Brown!";
    	String hash = generateHash(data);
        return "<p>data: "+ data + "</p><p>SHA-256 Hash: " + hash + "</p>";
    }
    
    private String generateHash(String input) {
    	try {
    		MessageDigest digest = MessageDigest.getInstance("SHA-256");
    		byte[] hashBytes = digest.digest(input.getBytes());
    		
    		return bytesToHex(hashBytes);
    	} catch(NoSuchAlgorithmException e) {
    		throw new RuntimeException("Error generating hash", e);
    	}
    }
    
    private String bytesToHex(byte[] bytes) {
    	StringBuilder hexString = new StringBuilder();
    	for (byte b : bytes) {
    		hexString.append(String.format("%02x", b));
    	}
    	return hexString.toString();
    }

}
